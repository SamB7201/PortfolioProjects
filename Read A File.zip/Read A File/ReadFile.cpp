
#include <iostream>
#include <iomanip>
#include <fstream>
#include "account.h"
using namespace std;

account myAccount;

void newBalance();
void checkLimit();

int main()
{
    int acc;
    double bal, cha, cre, all;
    ifstream fin;

    fin.open("info.txt");

    if (!fin.is_open()) {
        cout << "Cannot open file" << endl;
        exit(1);
    }

    while (!fin.eof()) {
        fin >> acc >> bal >> cha >> cre >> all;
        myAccount.setAccNum(acc);
        myAccount.setBegBal(bal);
        myAccount.setCharge(cha);
        myAccount.setCredit(cre);
        myAccount.setAllowed(all);
        cout << "\n\nStarting: " << myAccount << endl;
        newBalance();
        checkLimit();
    }

    fin.close();
}

void newBalance() {
    double newBal = 0;
    newBal = myAccount.getBegBal() + myAccount.getCharge() - myAccount.getCredit();
    myAccount.setBegBal(newBal);

    cout << "New Balance: " << myAccount << endl;
}

void checkLimit() {
    if (myAccount.getBegBal() > myAccount.getAllowed()) {
        cout << "CREDIT LIMIT EXCEEDED\n" << myAccount << endl;
    }
}