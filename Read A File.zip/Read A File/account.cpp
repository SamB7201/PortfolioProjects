#include "account.h"
#include <iomanip>
#include <iostream>
using namespace std;

account::account() {
	accNum = 0;
	begBal = 0;
	charge = 0;
	credit = 0;
	allowed = 0;
}
account::account(int Acc, double Beg, double Cha, double Cre, double All) {
	this->accNum = Acc;
	this->begBal = Beg;
	this->charge = Cha;
	this->credit = Cre;
	this->allowed = All;
}

void account::setAccNum(int Acc) {
	this->accNum = Acc;
}
void account::setBegBal(double Beg) {
	this->begBal = Beg;
}
void account::setCharge(double Cha) {
	this->charge = Cha;
}
void account::setCredit(double Cre) {
	this->credit = Cre;
}
void account::setAllowed(double All) {
	this->allowed = All;
}

int account::getAccNum() {
	return accNum;
}
double account::getBegBal() {
	return begBal;
}
double account::getCharge() {
	return charge;
}
double account::getCredit() {
	return credit;
}
double account::getAllowed() {
	return allowed;
}

ostream& operator<<(ostream& out, const account& acc) {
	out << fixed << setprecision(2);
	out << acc.accNum << ", " << acc.begBal << ", " << acc.charge << ", " << acc.credit << ", " << acc.allowed;
	return out;
}