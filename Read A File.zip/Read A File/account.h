#pragma once

#include <string>
using namespace std;
class account
{
public:
	account();
	account(int Acc, double Beg, double Cha, double Cre, double All);

	void setAccNum(int Acc);
	void setBegBal(double Beg);
	void setCharge(double Cha);
	void setCredit(double Cre);
	void setAllowed(double All);

	int getAccNum();
	double getBegBal();
	double getCharge();
	double getCredit();
	double getAllowed();

	string to_string() {
		string output = "";
		output = std::to_string(accNum) + ", " + std::to_string(begBal) + ", " +
			std::to_string(charge) + ", " + std::to_string(credit) + ", " +
			std::to_string(allowed);

		return output;
	}

	friend ostream& operator <<(ostream& out, const account& acc);

protected:
	int accNum;
	double begBal, charge, credit, allowed;


};

