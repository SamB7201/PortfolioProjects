
package bookstorecredit;
import java.util.Scanner;
public class BookstoreCredit {
    public static void main(String[] args) {
        
        String name;
        double gpa, gpa1;
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter name");
        name = input.nextLine();
        System.out.println("Enter GPA");
        gpa = input.nextDouble();
        
        gpa1 = multGpa(gpa);
        
        System.out.println(name + " your gpa is " + gpa + " and you get $" + gpa1 + " in the bookstore!");
    }
    public static double multGpa(double x){
        double answer;
        answer = (x * 10);
        return answer;
        
    }
    
}
